﻿Public Class frmSamCalculator
    Private Sub btnCalcB_Click(sender As Object, e As EventArgs) Handles btnCalcB.Click
        '(b) Balance after NSSF 10%, PAYE 9%, SACCO 5%
        Dim monthlySalary As Double = Val(txtSalary.Text)

        Dim nssf As Double = 0.1 * monthlySalary
        Dim paye As Double = 0.09 * monthlySalary
        Dim sacco As Double = 0.05 * monthlySalary

        Dim totalDeductions As Double = nssf + paye + sacco
        Dim balanceAfter As Double = monthlySalary - totalDeductions

        lblBalanceAfter.Text = "Balance After Deductions: " & balanceAfter & " UGX"

        MessageBox.Show("NSSF (10%) = " & nssf & vbCrLf & _
                        "PAYE (9%) = " & paye & vbCrLf & _
                        "SACCO (5%) = " & sacco & vbCrLf & _
                        "Balance After Deductions = " & balanceAfter)
    End Sub

    Private Sub btnCalcA_Click(sender As Object, e As EventArgs) Handles btnCalcA.Click
        ' (a) Total expenses on school fees and take hme balance 
        Dim monthlySalary As Double = Val(txtSalary.Text)
        Dim dependants As Integer = Val(txtDependants.Text)
        Dim schoolfees As Double = Val(txtFees.Text)

        Dim totalExpenses As Double = dependants * schoolfees
        Dim takeHomeBalance As Double = monthlySalary - totalExpenses

        lblTotalExp.Text = "Total Expenses: " & totalExpenses & " UGX"
        lblTakeHome.Text = "Take Home Balance: " & takeHomeBalance & " UGX"

        MessageBox.Show("Total Expenses = " & totalExpenses & " UGX" & vbCrLf & "Take Home = " & takeHomeBalance & " UGX")

    End Sub

End Class
